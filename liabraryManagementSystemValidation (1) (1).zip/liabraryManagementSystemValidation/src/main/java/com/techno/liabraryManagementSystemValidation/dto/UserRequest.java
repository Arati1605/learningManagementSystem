package com.techno.liabraryManagementSystemValidation.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;


public class UserRequest {
	@NotNull(message= "id Should Not be null. please enter  id")
	private Long uid;
	@NotBlank(message= "Name Should Not be empty. please enter your name")
	private String username;
//	@Pattern(regexp = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\\\S+$).{8,}"
//			,message = "invalid Password entered ")
	
	@NotNull(message= "Password Should Not be null. please enter password")
	private Long password;
	@NotBlank(message= "Admin Name Should Not be empty.Admin name is required. please enter admin name")

	private String admin;
	public Long getUid() {
		return uid;
	}
	public void setUid(Long uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Long getPassword() {
		return password;
	}
	public void setPassword(Long password) {
		this.password = password;
	}
	public String getAdmin() {
		return admin;
	}
	public void setAdmin(String admin) {
		this.admin = admin;
	}
	
	

}

//(?=.*[0-9]) a digit must occur at least once
//(?=.*[a-z]) a lower case letter must occur at least once
//(?=.*[A-Z]) an upper case letter must occur at least once
//(?=.*[@#$%^&+=]) a special character must occur at least once
//(?=\\S+$) no whitespace allowed in the entire string
//.{8,} at least 8 characters
