package com.techno.liabraryManagementSystemValidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LiabraryManagementSystemValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LiabraryManagementSystemValidationApplication.class, args);
	}

}
