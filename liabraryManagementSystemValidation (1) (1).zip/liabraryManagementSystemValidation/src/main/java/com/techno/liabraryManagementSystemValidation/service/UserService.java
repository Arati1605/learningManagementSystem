package com.techno.liabraryManagementSystemValidation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techno.liabraryManagementSystemValidation.dto.UserRequest;
import com.techno.liabraryManagementSystemValidation.entity.UserEntity;
import com.techno.liabraryManagementSystemValidation.repository.UserRepository;


@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;

	public UserEntity saveUser(UserRequest userRequest) {
		UserEntity user = new UserEntity();
		
		user.setUid(userRequest.getUid());
		user.setUsername(userRequest.getUsername());
		user.setPassword(userRequest.getPassword());
		user.setAdmin(userRequest.getAdmin());

		return userRepository.save(user);
	}


}
