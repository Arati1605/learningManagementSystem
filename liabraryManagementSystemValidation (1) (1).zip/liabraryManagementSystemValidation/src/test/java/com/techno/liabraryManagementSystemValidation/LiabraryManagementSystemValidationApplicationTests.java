package com.techno.liabraryManagementSystemValidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiabraryManagementSystemValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
